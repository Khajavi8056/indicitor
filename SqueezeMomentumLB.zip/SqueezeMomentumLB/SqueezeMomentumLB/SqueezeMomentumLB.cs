using System;
using cAlgo.API;
using cAlgo.API.Collections;
using cAlgo.API.Indicators;
using cAlgo.API.Internals;

namespace cAlgo.Indicators
{
    [Indicator(IsOverlay = false, TimeZone = TimeZones.UTC, AccessRights = AccessRights.None)]
    public class SqueezeMomentumLB : Indicator
    {
        [Parameter("BB Length", DefaultValue = 20)]
        public int BbLength { get; set; }

        [Parameter("BB MultFactor", DefaultValue = 2.0)]
        public double BbMult { get; set; }

        [Parameter("KC Length", DefaultValue = 20)]
        public int KcLength { get; set; }

        [Parameter("KC MultFactor", DefaultValue = 1.5)]
        public double KcMult { get; set; }

        [Parameter("Use TrueRange", DefaultValue = true)]
        public bool UseTrueRange { get; set; }

        // هیستوگرام
        [Output("UpUp", PlotType = PlotType.Histogram, LineColor = "#00FF00", Thickness = 4)]
        public IndicatorDataSeries UpUp { get; set; }

        [Output("UpDown", PlotType = PlotType.Histogram, LineColor = "#008000", Thickness = 4)]
        public IndicatorDataSeries UpDown { get; set; }

        [Output("DownDown", PlotType = PlotType.Histogram, LineColor = "#FF0000", Thickness = 4)]
        public IndicatorDataSeries DownDown { get; set; }

        [Output("DownUp", PlotType = PlotType.Histogram, LineColor = "#800000", Thickness = 4)]
        public IndicatorDataSeries DownUp { get; set; }
   // اضافه شدن خط پایه برای رفع خطای ZeroLine
    [Output("ZeroLine", LineColor = "Gray", PlotType = PlotType.Line)]
    public IndicatorDataSeries ZeroLine { get; set; }

        // خط صفر
        [Output("ZeroSqzOn", PlotType = PlotType.Line, LineColor = "#000000", Thickness = 2)]
        public IndicatorDataSeries ZeroSqzOn { get; set; }

        [Output("ZeroSqzOff", PlotType = PlotType.Line, LineColor = "#808080", Thickness = 2)]
        public IndicatorDataSeries ZeroSqzOff { get; set; }

        [Output("ZeroNoSqz", PlotType = PlotType.Line, LineColor = "#0000FF", Thickness = 2)]
        public IndicatorDataSeries ZeroNoSqz { get; set; }

        private SimpleMovingAverage _basisSMA, _maSMA, _rangeSMA, _smaClose;
        private StandardDeviation _stdDev;
        private IndicatorDataSeries _rangeSeries;
        private TrueRange _tr;
        private IndicatorDataSeries _momentumSeries;

        protected override void Initialize()
        {
            _basisSMA = Indicators.SimpleMovingAverage(Bars.ClosePrices, BbLength);
            _stdDev = Indicators.StandardDeviation(Bars.ClosePrices, BbLength, MovingAverageType.Simple); // اصلاح خطا
            _maSMA = Indicators.SimpleMovingAverage(Bars.ClosePrices, KcLength);
            _rangeSeries = CreateDataSeries();
            _rangeSMA = Indicators.SimpleMovingAverage(_rangeSeries, KcLength);
            _tr = Indicators.TrueRange();
            _smaClose = Indicators.SimpleMovingAverage(Bars.ClosePrices, KcLength);
            _momentumSeries = CreateDataSeries();
        }

        public override void Calculate(int index)
        {
           ZeroLine[index] = 0;
            // محاسبه محدوده
            _rangeSeries[index] = UseTrueRange ? CalculateTrueRange(index) : Bars.HighPrices[index] - Bars.LowPrices[index];

            // Bollinger Bands
            double basis = _basisSMA.Result[index];
            double dev = BbMult * _stdDev.Result[index];
            double upperBB = basis + dev;
            double lowerBB = basis - dev;

            // Keltner Channel
            double ma = _maSMA.Result[index];
            double rangeMA = _rangeSMA.Result[index];
            double upperKC = ma + rangeMA * KcMult;
            double lowerKC = ma - rangeMA * KcMult;

            // شرایط Squeeze
            bool sqzOn = (lowerBB > lowerKC) && (upperBB < upperKC);
            bool sqzOff = (lowerBB < lowerKC) && (upperBB > upperKC);
            bool noSqz = !sqzOn && !sqzOff;

            // محاسبات مومنتوم
            double highest = GetHighestHigh(index, KcLength);
            double lowest = GetLowestLow(index, KcLength);
            double smaClose = _smaClose.Result[index];
            
            double avg1 = (highest + lowest) / 2.0;
            double avg2 = (avg1 + smaClose) / 2.0;
            double adjustedClose = Bars.ClosePrices[index] - avg2;

            // رگرسیون خطی
            double lr = CalculateLinearRegression(index, adjustedClose);
            _momentumSeries[index] = lr;

            // مدیریت رنگ‌ها
            HandleColors(index, lr, sqzOn, sqzOff, noSqz);
        }

        private double CalculateTrueRange(int index)
        {
            if (index < 1) return Bars.HighPrices[index] - Bars.LowPrices[index];
            
            return Math.Max(
                Bars.HighPrices[index] - Bars.LowPrices[index],
                Math.Max(
                    Math.Abs(Bars.HighPrices[index] - Bars.ClosePrices[index - 1]),
                    Math.Abs(Bars.LowPrices[index] - Bars.ClosePrices[index - 1])
                )
            );
        }

        private double GetHighestHigh(int index, int period)
        {
            double highest = double.MinValue;
            int start = Math.Max(index - period + 1, 0);
            
            for (int i = start; i <= index; i++)
                if (Bars.HighPrices[i] > highest)
                    highest = Bars.HighPrices[i];
            
            return highest;
        }

        private double GetLowestLow(int index, int period)
        {
            double lowest = double.MaxValue;
            int start = Math.Max(index - period + 1, 0);
            
            for (int i = start; i <= index; i++)
                if (Bars.LowPrices[i] < lowest)
                    lowest = Bars.LowPrices[i];
            
            return lowest;
        }

        private double CalculateLinearRegression(int index, double adjustedClose)
        {
            if (index < KcLength) return double.NaN;

            double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
            
            for (int i = 0; i < KcLength; i++)
            {
                int idx = index - i;
                double x = i;
                double y = Bars.ClosePrices[idx] - ((GetHighestHigh(idx, KcLength) + GetLowestLow(idx, KcLength))/2 + _smaClose.Result[idx])/2;
                
                sumX += x;
                sumY += y;
                sumXY += x * y;
                sumX2 += x * x;
            }
            
            double slope = (KcLength * sumXY - sumX * sumY) / (KcLength * sumX2 - sumX * sumX);
            return slope * (KcLength - 1) + (sumY/KcLength - slope * (sumX/KcLength));
        }

        private void HandleColors(int index, double currentValue, bool sqzOn, bool sqzOff, bool noSqz)
        {
            // ریست خروجی‌ها
            UpUp[index] = UpDown[index] = DownDown[index] = DownUp[index] = double.NaN;
            ZeroSqzOn[index] = ZeroSqzOff[index] = ZeroNoSqz[index] = double.NaN;

            // رنگ‌آمیزی هیستوگرام
            if (index < 1) return;
            
            double prevValue = _momentumSeries[index - 1];
            
            if (currentValue > 0)
                if (currentValue > prevValue)
                    UpUp[index] = currentValue;
                else
                    UpDown[index] = currentValue;
            else
                if (currentValue < prevValue)
                    DownDown[index] = currentValue;
                else
                    DownUp[index] = currentValue;

            // رنگ‌آمیزی خط صفر
            ZeroSqzOn[index] = sqzOn ? 0 : double.NaN;
            ZeroSqzOff[index] = sqzOff ? 0 : double.NaN;
            ZeroNoSqz[index] = noSqz ? 0 : double.NaN;
        }
    }
}